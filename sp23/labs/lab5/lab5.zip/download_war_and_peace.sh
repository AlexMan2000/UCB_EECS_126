curl 'https://www.gutenberg.org/files/2600/2600-0.txt' > war_and_peace.txt
